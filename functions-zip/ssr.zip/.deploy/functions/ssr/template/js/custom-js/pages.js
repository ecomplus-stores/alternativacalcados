// Add your custom JavaScript for storefront pages here.
if($('#container-home').length) {
    $('#container-home > .container').append($('#container-home').nextAll())
} 
 
